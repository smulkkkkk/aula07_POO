package Livraria;

public interface Livraria {
    double taxaEmprestimo = 2.8;

    void emprestarLivro();
    void venderLivro();
}
