package Olimpíada;

public interface Olimpiadas {
    String verificaSituacao();
}
